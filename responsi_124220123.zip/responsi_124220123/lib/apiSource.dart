import 'baseNetwork.dart';

class ApiDataSource {
  static ApiDataSource instance = ApiDataSource();

  Future<Map<String, dynamic>> loadRestaurants() {
    return BaseNetwork.get("articles/?format=json");
  }

  Future<Map<String, dynamic>> loaddetailRestaurants(int Id) {
    return BaseNetwork.get("articles/?format=json/$Id");
  }
}