import 'package:flutter/material.dart';
import 'restaurantModel.dart'; 
import 'package:url_launcher/url_launcher.dart';

class DetailRestaurant extends StatelessWidget {
  final Restaurant restaurant;

  const DetailRestaurant({super.key, required this.restaurant});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("DETAIL RESTAURANT"),
        backgroundColor: Colors.purple[50],
        centerTitle: true,
        elevation: 4,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Gambar
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  restaurant.pictureId ?? '',  // Ensure you have a valid image URL
                  height: 250,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(height: 16),

              // Nama restoran
              Text(
                restaurant.name ?? 'No name available',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.purple[900]),
              ),
              SizedBox(height: 20),

              // Deskripsi restoran
              Text(
                restaurant.description ?? 'No description available.',
                textAlign: TextAlign.justify,
                style: TextStyle(fontSize: 16, height: 1.6, color: Colors.grey[800]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

