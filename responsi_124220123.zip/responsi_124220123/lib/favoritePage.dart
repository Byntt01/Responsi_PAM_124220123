import 'package:flutter/material.dart';

class FavoritesPage extends StatelessWidget {
  final List<String> favorites; // Daftar favorit

  const FavoritesPage({Key? key, required this.favorites}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Favorites"),
        backgroundColor: Colors.redAccent,
      ),
      body: favorites.isEmpty
          ? Center(
              child: Text(
                "No favorites added.",
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            )
          : ListView.builder(
              itemCount: favorites.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: Icon(Icons.favorite, color: Colors.red),
                  title: Text(
                    favorites[index],
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                );
              },
            ),
    );
  }
}
