import 'package:flutter/material.dart';
import 'apiSource.dart';
import 'detail_restaurant.dart';  // Assuming you have a Restaurant detail page.
import 'restaurantModel.dart';    // Assuming you have the RestaurantData model.

class RestList extends StatefulWidget {
  const RestList({Key? key}) : super(key: key);

  @override
  State<RestList> createState() => _RestList();
}

class _RestList extends State<RestList> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("RESTAURANT DETAIL", style: TextStyle(fontWeight: FontWeight.w600)),
        backgroundColor: Colors.grey[50],
        centerTitle: true,
        elevation: 4,
      ),
      body: _buildRestListBody(),
    );
  }

  Widget _buildRestListBody() {
    return Container(
      child: FutureBuilder<RestaurantData>(
          builder: (BuildContext context, AsyncSnapshot<RestaurantData> snapshot) {
            if (snapshot.hasError) {
              return _buildErrorSection();
            }
            if (snapshot.hasData) {
              return _buildSuccessSection(snapshot.data!.restaurant);  
            }
            return _buildLoadingSection();
          }, future: null,),
    );
  }

  Widget _buildErrorSection() {
    return Center(
      child: Text(
        "Error loading restaurants",
        style: TextStyle(fontSize: 18, color: Colors.red),
      ),
    );
  }

  Widget _buildSuccessSection(Restaurant restaurant) {
    return ListView.builder(
      itemCount: 1,  
      itemBuilder: (BuildContext context, int index) {
        return _BuildItemRestaurant(restaurant);
      },
    );
  }

  Widget _buildLoadingSection() {
    return Center(
      child: CircularProgressIndicator(),
    );
  }

  Widget _BuildItemRestaurant(Restaurant restaurant) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DetailRestaurant(restaurant: restaurant),  // Navigate to Restaurant Detail page
          ),
        );
      },
      child: Card(
        margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            // Gambar dengan border-radius dan shadow
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                restaurant.pictureId,  // Updated field to match your model
                width: 120,
                height: 100,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(width: 16),

            // Kolom dengan informasi restoran
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Nama restoran
                  Text(
                    restaurant.name,  // Using name field from Restaurant model
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),

                  // Deskripsi atau ringkasan restoran
                  Text(
                    restaurant.description,  // Using description field from Restaurant model
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
