class RestaurantData {
  RestaurantData({
    required this.error,
    required this.message,
    required this.restaurant,
  });

  late final bool error;
  late final String message;
  late final Restaurant restaurant;

  RestaurantData.fromJson(Map<String, dynamic> json) {
    error = json['error'];
    message = json['message'];
    restaurant = Restaurant.fromJson(json['restaurant']);
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['error'] = error;
    _data['message'] = message;
    _data['restaurant'] = restaurant.toJson();
    return _data;
  }
}

class Restaurant {
  Restaurant({
    required this.id,
    required this.name,
    required this.description,
    required this.city,
    required this.address,
    required this.pictureId,
    required this.categories,
    required this.menus,
    required this.rating,
    required this.customerReviews,
  });

  late final String id;
  late final String name;
  late final String description;
  late final String city;
  late final String address;
  late final String pictureId;
  late final List<Category> categories;
  late final Menus menus;
  late final double rating;
  late final List<CustomerReview> customerReviews;

  Restaurant.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    description = json['description'];
    city = json['city'];
    address = json['address'];
    pictureId = json['pictureId'];
    categories = List.from(json['categories']).map((e) => Category.fromJson(e)).toList();
    menus = Menus.fromJson(json['menus']);
    rating = json['rating'].toDouble();
    customerReviews = List.from(json['customerReviews'])
        .map((e) => CustomerReview.fromJson(e))
        .toList();
  }

  get url => null;

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['id'] = id;
    _data['name'] = name;
    _data['description'] = description;
    _data['city'] = city;
    _data['address'] = address;
    _data['pictureId'] = pictureId;
    _data['categories'] = categories.map((e) => e.toJson()).toList();
    _data['menus'] = menus.toJson();
    _data['rating'] = rating;
    _data['customerReviews'] = customerReviews.map((e) => e.toJson()).toList();
    return _data;
  }
}

class Category {
  Category({
    required this.name,
  });

  late final String name;

  Category.fromJson(Map<String, dynamic> json) {
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['name'] = name;
    return _data;
  }
}

class Menus {
  Menus({
    required this.foods,
    required this.drinks,
  });

  late final List<MenuItem> foods;
  late final List<MenuItem> drinks;

  Menus.fromJson(Map<String, dynamic> json) {
    foods = List.from(json['foods']).map((e) => MenuItem.fromJson(e)).toList();
    drinks = List.from(json['drinks']).map((e) => MenuItem.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['foods'] = foods.map((e) => e.toJson()).toList();
    _data['drinks'] = drinks.map((e) => e.toJson()).toList();
    return _data;
  }
}

class MenuItem {
  MenuItem({
    required this.name,
  });

  late final String name;

  MenuItem.fromJson(Map<String, dynamic> json) {
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['name'] = name;
    return _data;
  }
}

class CustomerReview {
  CustomerReview({
    required this.name,
    required this.review,
    required this.date,
  });

  late final String name;
  late final String review;
  late final String date;

  CustomerReview.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    review = json['review'];
    date = json['date'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['name'] = name;
    _data['review'] = review;
    _data['date'] = date;
    return _data;
  }
}
