import 'package:flutter/material.dart';
import 'package:responsi_124220123/favoritePage.dart';
import 'list_restaurant.dart';
import 'detail_restaurant.dart';

class MenuUtama extends StatefulWidget {
  const MenuUtama({Key? key}) : super(key: key);

  @override
  State<MenuUtama> createState() => _MenuUtama();
}

class _MenuUtama extends State<MenuUtama> {
  final List<String> favorites = []; // Menyimpan ID atau nama restoran favorit

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Center(
            child: Column(
              children: [
                Text('List Restaurant'),
              ],
            ),
          ),
          actions: [
            IconButton(
              icon: Icon(Icons.favorite, color: Colors.red),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => FavoritesPage(favorites: favorites),
                  ),
                );
              },
            ),
          ],
        ),
        body: GridView.count(
          padding: const EdgeInsets.all(25),
          crossAxisCount: 1,
          children: <Widget>[
            // Restoran Melting Pot
            Card(
              margin: const EdgeInsets.all(8),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => RestList(),
                    ),
                  );
                },
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    CircleAvatar(
                      backgroundImage: AssetImage('assets/image/rest.png'),
                      radius: 100,
                    ),
                    Text(
                      "Melting Pot",
                      style: TextStyle(
                        fontSize: 25,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: Icon(
                        favorites.contains("Melting Pot")
                            ? Icons.favorite
                            : Icons.favorite_border,
                        color: Colors.red,
                      ),
                      onPressed: () {
                        setState(() {
                          if (favorites.contains("Melting Pot")) {
                            favorites.remove("Melting Pot");
                          } else {
                            favorites.add("Melting Pot");
                          }
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),
    
            Card(
              margin: const EdgeInsets.all(8),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => RestList(),
                    ),
                  );
                },
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    CircleAvatar(
                      backgroundImage: AssetImage('assets/image/rest.png'),
                      radius: 100,
                    ),
                    Text(
                      "Kafe Kita",
                      style: TextStyle(
                        fontSize: 25,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: Icon(
                        favorites.contains("Kafe Kita")
                            ? Icons.favorite
                            : Icons.favorite_border,
                        color: Colors.red,
                      ),
                      onPressed: () {
                        setState(() {
                          if (favorites.contains("Kafe Kita")) {
                            favorites.remove("Kafe Kita");
                          } else {
                            favorites.add("Kafe Kita");
                          }
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
