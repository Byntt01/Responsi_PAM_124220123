package com.example.responsi_124220123

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
